// Camada de dados. Usa o Vercel KV (Redis gratuito) pra guardar
// produtos, categorias e pedidos. Se um dia quiser trocar de banco,
// só precisa mexer neste arquivo.
const { kv } = require('@vercel/kv');

const KEYS = {
  products: 'erremby2:products',
  categories: 'erremby2:categories',
  order: (id) => `erremby2:order:${id}`,
  orders: 'erremby2:orders', // lista de ids, mais recentes primeiro
};

async function getProducts() {
  const products = await kv.get(KEYS.products);
  return products || [];
}

async function saveProducts(products) {
  await kv.set(KEYS.products, products);
}

async function getCategories() {
  const categories = await kv.get(KEYS.categories);
  return categories || [];
}

async function saveCategories(categories) {
  await kv.set(KEYS.categories, categories);
}

async function createOrder(order) {
  await kv.set(KEYS.order(order.id), order);
  const orders = (await kv.get(KEYS.orders)) || [];
  orders.unshift(order.id);
  // guarda só os últimos 200 pedidos na lista de índice
  await kv.set(KEYS.orders, orders.slice(0, 200));
}

async function getOrder(id) {
  return await kv.get(KEYS.order(id));
}

async function updateOrder(id, patch) {
  const current = await kv.get(KEYS.order(id));
  if (!current) return null;
  const updated = { ...current, ...patch };
  await kv.set(KEYS.order(id), updated);
  return updated;
}

async function listOrders(limit = 50) {
  const ids = (await kv.get(KEYS.orders)) || [];
  const slice = ids.slice(0, limit);
  const orders = await Promise.all(slice.map((id) => kv.get(KEYS.order(id))));
  return orders.filter(Boolean);
}

module.exports = {
  getProducts,
  saveProducts,
  getCategories,
  saveCategories,
  createOrder,
  getOrder,
  updateOrder,
  listOrders,
};
