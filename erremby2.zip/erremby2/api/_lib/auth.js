// Autenticação simples do painel. O painel manda a senha no
// cabeçalho "x-admin-password" e aqui a gente compara com a
// variável de ambiente ADMIN_PASSWORD (configurada na Vercel).
function isAdminRequest(req) {
  const sent = req.headers['x-admin-password'];
  const real = process.env.ADMIN_PASSWORD;
  if (!real) {
    // Se você esquecer de configurar a senha, bloqueia por segurança
    // em vez de deixar todo mundo editar os produtos.
    return false;
  }
  return sent === real;
}

function requireAdmin(req, res) {
  if (!isAdminRequest(req)) {
    res.status(401).json({ error: 'Senha de administrador inválida.' });
    return false;
  }
  return true;
}

module.exports = { isAdminRequest, requireAdmin };
