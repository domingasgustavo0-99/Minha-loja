// Envia um "embed" bonitinho pro canal do Discord sempre que
// uma venda é confirmada.
async function notifyDiscordSale(order) {
  const url = process.env.DISCORD_WEBHOOK_URL;
  if (!url) {
    console.warn('DISCORD_WEBHOOK_URL não configurado — pulando notificação.');
    return;
  }

  const itemsText = order.items
    .map((item) => `• ${item.quantity}x ${item.name} — R$ ${(item.price * item.quantity).toFixed(2)}`)
    .join('\n');

  const payload = {
    username: 'Vendas',
    embeds: [
      {
        title: '🟢 Nova venda confirmada!',
        color: 0x2ecc71,
        fields: [
          { name: 'Pedido', value: `#${order.id}`, inline: true },
          { name: 'Total', value: `R$ ${order.total.toFixed(2)}`, inline: true },
          { name: 'Itens', value: itemsText || 'Sem itens' },
        ],
        timestamp: new Date().toISOString(),
      },
    ],
  };

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    console.error('Falha ao notificar Discord:', response.status, await response.text());
  }
}

module.exports = { notifyDiscordSale };
