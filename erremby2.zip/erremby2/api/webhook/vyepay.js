const { getOrder, updateOrder, listOrders } = require('../_lib/db');
const { notifyDiscordSale } = require('../_lib/discord');

// ATENÇÃO: eu não consegui acessar a documentação completa da Vye
// (a página de credenciais pede login), então não sei 100% o nome
// exato dos campos que o webhook deles envia. Deixei este código
// flexível, tentando reconhecer os formatos mais comuns. Se não
// funcionar de primeira, me manda o JSON que a Vye realmente envia
// (dá pra ver isso nos logs da Vercel, aba "Logs") e eu ajusto certinho.

function extractStatus(body) {
  const raw =
    body.status || body.event || body.type || (body.data && body.data.status) || '';
  return String(raw).toLowerCase();
}

function extractPaymentId(body) {
  return (
    body.id ||
    body.paymentId ||
    body.payment_id ||
    (body.data && (body.data.id || body.data.paymentId)) ||
    null
  );
}

function extractOrderReference(body) {
  // Caso a Vye devolva de volta o campo de referência que a gente
  // mandou lá no checkout.js (description ou reference/externalId).
  const description = body.description || (body.data && body.data.description) || '';
  const match = String(description).match(/#(\w+)/);
  return match ? match[1] : null;
}

const PAID_KEYWORDS = ['paid', 'pago', 'confirmed', 'confirmado', 'completed', 'concluido', 'concluído', 'approved'];

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Método não permitido.' });
    return;
  }

  const body = req.body || {};
  console.log('Webhook Vye recebido:', JSON.stringify(body));

  const status = extractStatus(body);
  const isPaid = PAID_KEYWORDS.some((keyword) => status.includes(keyword));

  if (!isPaid) {
    // Não é uma notificação de pagamento confirmado — apenas confirma
    // o recebimento pra Vye não ficar reenviando.
    res.status(200).json({ ok: true, ignored: true });
    return;
  }

  let order = null;

  const orderRef = extractOrderReference(body);
  if (orderRef) {
    order = await getOrder(orderRef);
  }

  if (!order) {
    // Fallback: procura o pedido pendente cujo vyeId bate com o
    // id de pagamento recebido no webhook.
    const paymentId = extractPaymentId(body);
    if (paymentId) {
      const recent = await listOrders(200);
      order = recent.find((o) => o.vyeId === paymentId) || null;
    }
  }

  if (!order) {
    console.warn('Webhook Vye: não encontrei o pedido correspondente.', body);
    res.status(200).json({ ok: true, matched: false });
    return;
  }

  if (order.status === 'paid') {
    // Já processamos esse pedido antes (a Vye pode reenviar o webhook)
    res.status(200).json({ ok: true, alreadyProcessed: true });
    return;
  }

  const updated = await updateOrder(order.id, { status: 'paid', paidAt: new Date().toISOString() });
  await notifyDiscordSale(updated);

  res.status(200).json({ ok: true });
};
