const el = (id) => document.getElementById(id);
let adminPassword = sessionStorage.getItem('adminPassword') || '';

const state = { products: [], categories: [] };

function authHeaders() {
  return { 'Content-Type': 'application/json', 'x-admin-password': adminPassword };
}

async function tryLogin() {
  adminPassword = el('passwordInput').value;
  const res = await fetch('/api/categories', { headers: authHeaders() });
  if (res.status === 401) {
    el('loginError').textContent = 'Senha incorreta.';
    return;
  }
  sessionStorage.setItem('adminPassword', adminPassword);
  el('loginScreen').classList.add('hidden');
  el('adminApp').classList.remove('hidden');
  loadAll();
}

async function loadAll() {
  const [products, categories] = await Promise.all([
    fetch('/api/products').then((r) => r.json()),
    fetch('/api/categories').then((r) => r.json()),
  ]);
  state.products = products;
  state.categories = categories;
  renderCategories();
  renderProducts();
  fillCategorySelect();
}

function categoryName(id) {
  const cat = state.categories.find((c) => c.id === id);
  return cat ? cat.name : 'Sem categoria';
}

function renderCategories() {
  const list = el('categoryList');
  if (state.categories.length === 0) {
    list.innerHTML = '<p class="empty-state">Nenhuma categoria ainda.</p>';
    return;
  }
  list.innerHTML = '';
  state.categories.forEach((cat) => {
    const row = document.createElement('div');
    row.className = 'admin-row';
    row.innerHTML = `
      <div class="admin-row__info"><span class="admin-row__name">${cat.name}</span></div>
      <div class="admin-row__actions">
        <button class="btn" data-action="delete">Apagar</button>
      </div>
    `;
    row.querySelector('[data-action="delete"]').onclick = () => deleteCategory(cat.id);
    list.appendChild(row);
  });
}

function renderProducts() {
  const list = el('productList');
  if (state.products.length === 0) {
    list.innerHTML = '<p class="empty-state">Nenhum produto ainda.</p>';
    return;
  }
  list.innerHTML = '';
  state.products.forEach((product) => {
    const row = document.createElement('div');
    row.className = 'admin-row';
    row.innerHTML = `
      <div class="admin-row__info">
        <span class="admin-row__name">${product.name} ${product.active === false ? '(oculto)' : ''}</span>
        <span class="admin-row__meta">R$ ${product.price.toFixed(2)} · ${categoryName(product.categoryId)}</span>
      </div>
      <div class="admin-row__actions">
        <button class="btn" data-action="edit">Editar</button>
        <button class="btn" data-action="delete">Apagar</button>
      </div>
    `;
    row.querySelector('[data-action="edit"]').onclick = () => openProductModal(product);
    row.querySelector('[data-action="delete"]').onclick = () => deleteProduct(product.id);
    list.appendChild(row);
  });
}

function fillCategorySelect() {
  const select = el('productCategory');
  select.innerHTML = '<option value="">Sem categoria</option>';
  state.categories.forEach((cat) => {
    const opt = document.createElement('option');
    opt.value = cat.id;
    opt.textContent = cat.name;
    select.appendChild(opt);
  });
}

function openProductModal(product) {
  el('productModalTitle').textContent = product ? 'Editar produto' : 'Novo produto';
  el('productId').value = product ? product.id : '';
  el('productName').value = product ? product.name : '';
  el('productDescription').value = product ? product.description : '';
  el('productPrice').value = product ? product.price : '';
  el('productImage').value = product ? product.imageUrl : '';
  el('productCategory').value = product ? (product.categoryId || '') : '';
  el('productActive').checked = product ? product.active !== false : true;
  showModal('productModal');
}

async function saveProduct() {
  const id = el('productId').value;
  const payload = {
    name: el('productName').value,
    description: el('productDescription').value,
    price: Number(el('productPrice').value),
    imageUrl: el('productImage').value,
    categoryId: el('productCategory').value || null,
    active: el('productActive').checked,
  };
  if (!payload.name || !payload.price) {
    alert('Preencha nome e preço.');
    return;
  }
  const method = id ? 'PUT' : 'POST';
  if (id) payload.id = id;
  const res = await fetch('/api/products', { method, headers: authHeaders(), body: JSON.stringify(payload) });
  if (!res.ok) { alert('Erro ao salvar produto.'); return; }
  hideModal('productModal');
  loadAll();
}

async function deleteProduct(id) {
  if (!confirm('Apagar este produto?')) return;
  await fetch(`/api/products?id=${id}`, { method: 'DELETE', headers: authHeaders() });
  loadAll();
}

async function saveCategory() {
  const name = el('categoryName').value;
  if (!name) { alert('Digite um nome.'); return; }
  const res = await fetch('/api/categories', { method: 'POST', headers: authHeaders(), body: JSON.stringify({ name }) });
  if (!res.ok) { alert('Erro ao salvar categoria.'); return; }
  el('categoryName').value = '';
  hideModal('categoryModal');
  loadAll();
}

async function deleteCategory(id) {
  if (!confirm('Apagar esta categoria? Os produtos dela ficam sem categoria.')) return;
  await fetch(`/api/categories?id=${id}`, { method: 'DELETE', headers: authHeaders() });
  loadAll();
}

function showModal(id) { el(id).classList.add('pix-modal--open'); el('overlay').classList.add('overlay--visible'); }
function hideModal(id) { el(id).classList.remove('pix-modal--open'); el('overlay').classList.remove('overlay--visible'); }

el('loginButton').onclick = tryLogin;
el('newProductBtn').onclick = () => openProductModal(null);
el('newCategoryBtn').onclick = () => { el('categoryName').value = ''; showModal('categoryModal'); };
el('saveProductButton').onclick = saveProduct;
el('saveCategoryButton').onclick = saveCategory;
el('closeProductModal').onclick = () => hideModal('productModal');
el('closeCategoryModal').onclick = () => hideModal('categoryModal');
el('overlay').onclick = () => { hideModal('productModal'); hideModal('categoryModal'); };

// Se já tiver senha guardada nesta aba, tenta entrar direto
if (adminPassword) {
  el('passwordInput').value = adminPassword;
  tryLogin();
}
