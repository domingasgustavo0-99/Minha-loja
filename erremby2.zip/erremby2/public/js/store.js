const state = {
  products: [],
  categories: [],
  cart: {}, // { productId: quantity }
  activeCategory: 'all',
};

const el = (id) => document.getElementById(id);

function formatMoney(value) {
  return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

async function loadData() {
  const [products, categories] = await Promise.all([
    fetch('/api/products').then((r) => r.json()),
    fetch('/api/categories').then((r) => r.json()),
  ]);
  state.products = products.filter((p) => p.active !== false);
  state.categories = categories;
  renderCategories();
  renderProducts();
}

function renderCategories() {
  const nav = el('categoryNav');
  nav.innerHTML = '';

  const allChip = document.createElement('button');
  allChip.className = 'category-chip' + (state.activeCategory === 'all' ? ' category-chip--active' : '');
  allChip.textContent = 'Tudo';
  allChip.onclick = () => { state.activeCategory = 'all'; renderCategories(); renderProducts(); };
  nav.appendChild(allChip);

  state.categories.forEach((cat) => {
    const chip = document.createElement('button');
    chip.className = 'category-chip' + (state.activeCategory === cat.id ? ' category-chip--active' : '');
    chip.textContent = cat.name;
    chip.onclick = () => { state.activeCategory = cat.id; renderCategories(); renderProducts(); };
    nav.appendChild(chip);
  });
}

function renderProducts() {
  const grid = el('productGrid');
  const visible = state.products.filter(
    (p) => state.activeCategory === 'all' || p.categoryId === state.activeCategory
  );

  if (visible.length === 0) {
    grid.innerHTML = '<p class="empty-state">Nenhum produto por aqui ainda.</p>';
    return;
  }

  grid.innerHTML = '';
  visible.forEach((product) => {
    const card = document.createElement('article');
    card.className = 'product-card';
    card.innerHTML = `
      <img class="product-card__image" src="${product.imageUrl || ''}" alt="${product.name}" onerror="this.style.opacity=0">
      <div class="product-card__body">
        <h3 class="product-card__name">${product.name}</h3>
        <p class="product-card__desc">${product.description || ''}</p>
      </div>
      <div class="product-card__perforation"></div>
      <div class="product-card__footer">
        <span class="product-card__price mono">${formatMoney(product.price)}</span>
        <button class="btn btn--primary">Adicionar</button>
      </div>
    `;
    card.querySelector('button').onclick = () => addToCart(product.id);
    grid.appendChild(card);
  });
}

function addToCart(productId) {
  state.cart[productId] = (state.cart[productId] || 0) + 1;
  renderCart();
  openCart();
}

function changeQuantity(productId, delta) {
  const next = (state.cart[productId] || 0) + delta;
  if (next <= 0) {
    delete state.cart[productId];
  } else {
    state.cart[productId] = next;
  }
  renderCart();
}

function renderCart() {
  const items = el('cartItems');
  const entries = Object.entries(state.cart);
  const totalCount = entries.reduce((sum, [, qty]) => sum + qty, 0);
  el('cartCount').textContent = totalCount;

  if (entries.length === 0) {
    items.innerHTML = '<p class="empty-state">Seu carrinho está vazio.</p>';
    el('cartTotal').textContent = formatMoney(0);
    return;
  }

  let total = 0;
  items.innerHTML = '';
  entries.forEach(([productId, qty]) => {
    const product = state.products.find((p) => p.id === productId);
    if (!product) return;
    total += product.price * qty;
    const row = document.createElement('div');
    row.className = 'cart-item';
    row.innerHTML = `
      <div>
        <div class="cart-item__name">${product.name}</div>
        <div class="cart-item__qty">${formatMoney(product.price)} un.</div>
      </div>
      <div class="cart-item__controls">
        <button class="qty-btn" data-action="minus">−</button>
        <span class="mono">${qty}</span>
        <button class="qty-btn" data-action="plus">+</button>
      </div>
    `;
    row.querySelector('[data-action="minus"]').onclick = () => changeQuantity(productId, -1);
    row.querySelector('[data-action="plus"]').onclick = () => changeQuantity(productId, 1);
    items.appendChild(row);
  });

  el('cartTotal').textContent = formatMoney(total);
}

function openCart() {
  el('cartPanel').classList.add('cart-panel--open');
  el('overlay').classList.add('overlay--visible');
}
function closeCart() {
  el('cartPanel').classList.remove('cart-panel--open');
  el('overlay').classList.remove('overlay--visible');
}

let pollTimer = null;

async function startCheckout() {
  const items = Object.entries(state.cart).map(([productId, quantity]) => ({ productId, quantity }));
  if (items.length === 0) return;

  el('checkoutButton').disabled = true;
  el('checkoutButton').textContent = 'Gerando PIX…';

  try {
    const response = await fetch('/api/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items }),
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Erro ao gerar pagamento.');

    el('pixOrderId').textContent = data.orderId;
    el('pixAmount').textContent = formatMoney(data.total);
    el('pixQrImage').src = data.qrCode || '';
    el('pixCopyPaste').value = data.copyPaste || '';
    el('pixStatus').textContent = 'Aguardando pagamento…';
    el('pixStatus').className = 'pix-modal__status';
    openPixModal();
    closeCart();
    pollOrderStatus(data.orderId);
  } catch (err) {
    alert(err.message);
  } finally {
    el('checkoutButton').disabled = false;
    el('checkoutButton').textContent = 'Pagar com PIX';
  }
}

function pollOrderStatus(orderId) {
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = setInterval(async () => {
    try {
      const res = await fetch(`/api/order-status?id=${orderId}`);
      const data = await res.json();
      if (data.status === 'paid') {
        el('pixStatus').textContent = '✓ Pagamento confirmado!';
        el('pixStatus').className = 'pix-modal__status pix-modal__status--paid';
        clearInterval(pollTimer);
        state.cart = {};
        renderCart();
      }
    } catch (e) { /* tenta de novo na próxima */ }
  }, 3000);
}

function openPixModal() { el('pixModal').classList.add('pix-modal--open'); el('overlay').classList.add('overlay--visible'); }
function closePixModal() {
  el('pixModal').classList.remove('pix-modal--open');
  el('overlay').classList.remove('overlay--visible');
  if (pollTimer) clearInterval(pollTimer);
}

el('cartButton').onclick = openCart;
el('closeCart').onclick = closeCart;
el('checkoutButton').onclick = startCheckout;
el('closePix').onclick = closePixModal;
el('overlay').onclick = () => { closeCart(); closePixModal(); };
el('copyPixButton').onclick = () => {
  el('pixCopyPaste').select();
  document.execCommand('copy');
  el('copyPixButton').textContent = 'Copiado!';
  setTimeout(() => { el('copyPixButton').textContent = 'Copiar'; }, 1500);
};

loadData();
